console.log("hello world");

//! to execute any file type

// node filename.js
// node demo.js

// is extension necessary, extension is not mandatory

// path ==> /Desktop/Node 0700
